const box = document.getElementById('box');

const allChildren = document.getElementsByTagName('div').length;

/*const directChildren = box.children.length;
console.log(directChildren); */

prompt(allChildren)